(function ($) {
	"use strict";

    jQuery(document).ready(function($){


        $(".embed-responsive iframe").addClass("embed-responsive-item");
        $(".carousel-inner .item:first-child").addClass("active");
        
        $('[data-toggle="tooltip"]').tooltip();



        $(".header-area").sticky({topspacing: 0});
		
		
			
		//jQuery smooth scroll
		$('li.smooth-menu a').bind('click',function(event){
			var $anchor = $(this);
			var headerH = '60';
			$('html, body').stop().animate({
				scrollTop : $($anchor.attr('herf')).offset().top - headerH + "px"
			}, 1200,'easeInOutExpo');
			
			event.preventDefault();
			});
			
			//jQuery scroll pay
			$('body').scollspy({
				target:'.navbar-collapse',
				offset:95
			});
			
			$('.parallax-bg').scrolly({bgParallax: true});

    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	